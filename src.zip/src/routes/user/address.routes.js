//asgr                 //priyanshu
import { Router } from "express";
import {
  createAddress,
  getAddressesByUser,
  updateAddress,
  deleteAddress,
} from "../../controllers/user/address.controller.js";
import { addressValidation } from "../../validations/auth/address.validation.js";
import { validateRequest } from "../../middlewares/validation.js";
import { authMiddleware } from "../../middlewares/auth.js";

const router = Router();

router.post(
  "/",
  authMiddleware,
  validateRequest(addressValidation.createAddress),
  createAddress,
);
router.get("/", authMiddleware, getAddressesByUser);
router.put(
  "/:id",
  authMiddleware,
  validateRequest(addressValidation.updateAddress),
  updateAddress,
);
router.delete(
  "/:id",
  authMiddleware,
  validateRequest(addressValidation.addressId),
  deleteAddress,
);

export default router;
