import { Router } from 'express';

const router = Router();

// Placeholder
// router.get('/', ...);

export default router;
