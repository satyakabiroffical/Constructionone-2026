//asgr
import mongoose from "mongoose";

const vendorProfile = new mongoose.Schema(
  {
    moduleId: {
      type: mongoose.Schema.Types.ObjectId, //business setup Id
      ref: "Module",
    },
    phoneNumber: {
      type: String,
      sparse: true,
    },
    phoneOtp: {
      codeHash: String,
      expiresAt: Date,
      attempts: { type: Number, default: 0 },
      lastSentAt: Date,
    },
    firstName: { type: String },
    lastName: { type: String },
    email: { type: String },

    governmentIdType: {
      type: String,
      enum: ["Aadhar Card", "Voter ID", "Driving License", "Other"],
    },

    governmentIdNumber: { type: String },
    uploadId: { type: String },

    aadharOtp: {
      codeHash: String,
      expiresAt: Date,
      attempts: { type: Number, default: 0 },
      lastSentAt: Date,
    },
    isPhoneVerified: {
      type: Boolean,
      default: false,
    },
    isAadharVerified: {
      type: Boolean,
      default: false,
    },
    isAdminVerified: {
      type: Boolean,
      default: false,
    },
    isProfileCompleted: {
      type: Boolean,
      default: false,
    },

    disable: {
      type: Boolean,
      default: false,
    },

    fcmToken: {
      type: String,
      default: null,
    },
    avgRating: {
      type: Number,
      default: 0,
    },

    totalReviews: {
      type: Number,
      default: 0,
    },

    recommendationPercentage: {
      type: Number,
      default: 0,
    },

    ratingBreakdown: {
      5: { type: Number, default: 0 },
      4: { type: Number, default: 0 },
      3: { type: Number, default: 0 },
      2: { type: Number, default: 0 },
      1: { type: Number, default: 0 },
    },
  },
  { timestamps: true },
);

const vendorCompany = new mongoose.Schema(
  {
    vendorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "vendorProfile",
    },
    companyName: { type: String },
    companyType: {
      type: String,
      enum: [
        "Private Limited",
        "Public Limited",
        "Partnership",
        "Proprietorship",
        "Other",
      ],
      default: "Other",
    },
    businessCategory: {
      type: String,
      enum: ["Retail", "Wholesale", "E-commerce", "Production", "Other"],
      default: "Other",
    },
    serviceArea: {
      selectedStates: [String],
      selectedCities: [String],
      pinCodes: [String],
    },

    companyRegistrationNumber: { type: String },

    businessAddress: {
      address: String,
      city: String,
      state: String,
      country: String,
      pincode: String,
      latitude: Number,
      longitude: Number,
    },

    location: {
      //Sanvi
      type: {
        type: String,
        enum: ["Point"],
        default: "Point",
      },
      coordinates: {
        type: [Number], // [lng, lat]
      },
    },

    gstNumber: { type: String },
    contactNumber: { type: String },
    // accountHolderName: { type: String },
    // bankName: { type: String },
    // accountNumber: { type: String },
    // confirmAccountNumber: { type: String },
    // ifscCode: { type: String },
    // accountType: {
    //   type: String,
    //   enum: ["Saving", "Current", "NRO", "NRE", "Other"],
    //   default: "Other",
    // },
    // upiId: { type: String },
    shopImages: [String],
    certificates: [String],
    // cancelledCheque: { type: String },
    companyWebsiteURl: { type: String },

    badges: [
      {
        type: String,
        enum: [
          "TOP VENDOR",
          "MOST SOLD",
          "FAST DELIVERY",
          "HIGH RATING",
          "TRUSTED SELLER",
          "ADMIN PICK",
        ],
        default: [""],
      },
    ],

    isOpen: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true },
);

// ================= GEO AUTO SET =================
// auto set location on create
vendorCompany.pre("save", function (next) {
  if (this.businessAddress?.latitude && this.businessAddress?.longitude) {
    this.location = {
      type: "Point",
      coordinates: [
        this.businessAddress.longitude,
        this.businessAddress.latitude,
      ],
    };
  }
  next();
});
// auto set location on update
vendorCompany.pre("findOneAndUpdate", function (next) {
  const update = this.getUpdate();
  const data = update.$set || update;

  if (data?.businessAddress?.latitude && data?.businessAddress?.longitude) {
    update.$set = update.$set || {};
    update.$set.location = {
      type: "Point",
      coordinates: [
        data.businessAddress.longitude,
        data.businessAddress.latitude,
      ],
    };
  }

  next();
});

// geo index
vendorCompany.index({ location: "2dsphere" });
export const VendorProfile = mongoose.model("vendorProfile", vendorProfile);
export const VendorCompany = mongoose.model("vendorCompany", vendorCompany);

//demo test
const vendorBankSchema = new mongoose.Schema(
  {
    vendorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "vendorProfile",
      required: true,
    },

    accountHolderName: String,
    bankName: String,
    accountNumber: String,
    ifscCode: String,
    cancelledCheque: { type: String },

    accountType: {
      type: String,
      enum: ["Saving", "Current", "NRO", "NRE", "Other"],
      default: "Other",
    },

    upiId: String,

    isActive: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true },
);

const vendorAddressSchema = new mongoose.Schema(
  {
    vendorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "vendorProfile",
    },

    addressType: {
      type: String,
      enum: ["Office", "Warehouse", "Shop", "Factory", "Other"],
      default: "Other",
    },

    address: String,
    city: String,
    state: String,
    country: String,
    pincode: String,

    latitude: Number,
    longitude: Number,

    isPrimary: {
      type: Boolean,
      default: false,
    },

    location: {
      type: {
        type: String,
        enum: ["Point"],
        default: "Point",
      },
      coordinates: {
        type: [Number], // [lng, lat]
      },
    },
  },
  { timestamps: true },
);

vendorAddressSchema.index({ location: "2dsphere" });
